# Azure Function for formatting JSON changes as HTML English text
Sample code in JavaSCript for creating an Azure Function that generates HTML from the JSON changes web service output 

The project is arranged for downloading to a PC using Git and depoying to Azure using the Visual Studio Code extensions for Azure Functions.
